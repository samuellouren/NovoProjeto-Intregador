import { useState, useEffect } from 'react'
import { useNavigate } from 'react-router-dom'
import { useAuth } from '../context/AuthContext'
import axios from 'axios'
import './Candidates.css'
import Header from '../components/Header'

export default function Candidates() {
  const [candidates, setCandidates] = useState([])
  const [filteredCandidates, setFilteredCandidates] = useState([])
  const [searchTerm, setSearchTerm] = useState('')
  const [favorites, setFavorites] = useState(new Set())
  const navigate = useNavigate()

  useEffect(() => {
    fetchCandidates()
  }, [])

  useEffect(() => {
    const filtered = candidates.filter(candidate =>
      candidate.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      candidate.email.toLowerCase().includes(searchTerm.toLowerCase())
    )
    setFilteredCandidates(filtered)
  }, [searchTerm, candidates])

  const fetchCandidates = async () => {
    try {
      const response = await axios.get('/api/users')
      setCandidates(response.data)
      setFilteredCandidates(response.data)
    } catch (error) {
      console.error('Erro ao buscar candidatos:', error)
    }
  }

  const handleAddCandidate = () => {
    navigate('/add-candidate')
  }

  const toggleFavorite = (id) => {
    setFavorites(prev => {
      const newFavorites = new Set(prev)
      if (newFavorites.has(id)) {
        newFavorites.delete(id)
      } else {
        newFavorites.add(id)
      }
      return newFavorites
    })
  }

  return (
    <div className="candidates-container">
      <Header />

      <main className="candidates-main">
        <div className="search-section">
          <div className="section-header">
            <h2>Candidatos</h2>
            <button onClick={handleAddCandidate} className="btn-add">
              + Adicionar Candidato
            </button>
          </div>
          
          <input
            type="text"
            placeholder="Buscar por nome ou email..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="search-input"
          />
        </div>

        <div className="candidates-grid">
          {filteredCandidates.map((candidate) => (
            <div key={candidate.id} className="candidate-card">
              <div className="card-header">
                <div className="avatar">
                  {candidate.name.charAt(0).toUpperCase()}
                </div>
                <button
                  onClick={() => toggleFavorite(candidate.id)}
                  className={`favorite-button ${favorites.has(candidate.id) ? 'active' : ''}`}
                >
                  {favorites.has(candidate.id) ? '★' : '☆'}
                </button>
              </div>
              <h3>{candidate.name}</h3>
              <p className="email">{candidate.email}</p>
              <p className="date">
                Cadastrado em: {new Date(candidate.created_at).toLocaleDateString('pt-BR')}
              </p>
            </div>
          ))}
        </div>

        {filteredCandidates.length === 0 && (
          <div className="no-results">
            <p>Nenhum candidato encontrado</p>
            <button onClick={handleAddCandidate} className="btn-add-empty">
              + Adicionar Primeiro Candidato
            </button>
          </div>
        )}
      </main>
    </div>
  )
}
