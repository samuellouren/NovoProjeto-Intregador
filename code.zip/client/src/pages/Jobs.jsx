import { useState, useEffect } from 'react'
import { useNavigate } from 'react-router-dom'
import axios from 'axios'
import Header from '../components/Header'
import './Jobs.css'

export default function Jobs() {
  const [jobs, setJobs] = useState([])
  const [filteredJobs, setFilteredJobs] = useState([])
  const [searchTerm, setSearchTerm] = useState('')
  const navigate = useNavigate()

  // Carrega vagas quando componente é montado
  useEffect(() => {
    fetchJobs()
  }, [])

  // Filtra vagas baseado na busca
  useEffect(() => {
    const filtered = jobs.filter(job =>
      job.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
      job.company.toLowerCase().includes(searchTerm.toLowerCase())
    )
    setFilteredJobs(filtered)
  }, [searchTerm, jobs])

  // Busca vagas do backend
  const fetchJobs = async () => {
    try {
      const response = await axios.get('/api/jobs')
      console.log('[v0] Vagas carregadas:', response.data)
      setJobs(response.data)
      setFilteredJobs(response.data)
    } catch (error) {
      console.error('[v0] Erro ao buscar vagas:', error)
    }
  }

  // Navega para página de adicionar vaga
  const handleAddJob = () => {
    navigate('/add-job')
  }

  return (
    <div className="jobs-container">
      <Header />

      <main className="jobs-main">
        <div className="search-section">
          <div className="section-header">
            <h2>Vagas Disponíveis</h2>
            <button onClick={handleAddJob} className="btn-add">
              + Adicionar Vaga
            </button>
          </div>
          
          <input
            type="text"
            placeholder="Buscar por título ou empresa..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="search-input"
          />
        </div>

        <div className="jobs-grid">
          {filteredJobs.map((job) => (
            <div key={job.id} className="job-card">
              <div className="job-header">
                <h3>{job.title}</h3>
                <span className="job-type">{job.type}</span>
              </div>
              
              <p className="company">{job.company}</p>
              <p className="location">{job.location}</p>
              
              <p className="description">{job.description}</p>
              
              <div className="job-footer">
                <span className="salary">{job.salary}</span>
                <button className="btn-details">Ver Detalhes</button>
              </div>
            </div>
          ))}
        </div>

        {filteredJobs.length === 0 && (
          <div className="no-results">
            <p>Nenhuma vaga encontrada</p>
            <button onClick={handleAddJob} className="btn-add-empty">
              + Adicionar Primeira Vaga
            </button>
          </div>
        )}
      </main>
    </div>
  )
}
