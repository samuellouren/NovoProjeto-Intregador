import express from 'express'
import db from '../config/database.js'

const router = express.Router()

// Listar todos os candidatos
router.get('/candidates', (req, res) => {
  try {
    console.log('[v0] Buscando candidatos...')
    const candidates = db.prepare('SELECT * FROM candidates ORDER BY created_at DESC').all()
    res.json(candidates)
  } catch (error) {
    console.error('[v0] Erro ao buscar candidatos:', error)
    res.status(500).json({ message: 'Erro ao buscar candidatos' })
  }
})

// Adicionar novo candidato
router.post('/candidates', (req, res) => {
  try {
    const { name, email, phone, skills, experience, education } = req.body

    // Validação básica
    if (!name || !email) {
      return res.status(400).json({ message: 'Nome e email são obrigatórios' })
    }

    console.log('[v0] Adicionando candidato:', name)

    // Insere candidato no banco
    const stmt = db.prepare(`
      INSERT INTO candidates (name, email, phone, skills, experience, education)
      VALUES (?, ?, ?, ?, ?, ?)
    `)
    
    const result = stmt.run(name, email, phone, skills, experience, education)
    
    res.status(201).json({ 
      message: 'Candidato adicionado com sucesso',
      id: result.lastInsertRowid 
    })
  } catch (error) {
    console.error('[v0] Erro ao adicionar candidato:', error)
    
    // Verifica se é erro de email duplicado
    if (error.message.includes('UNIQUE')) {
      return res.status(400).json({ message: 'Email já cadastrado' })
    }
    
    res.status(500).json({ message: 'Erro ao adicionar candidato' })
  }
})

export default router
