import express from 'express'
import db from '../config/database.js'

const router = express.Router()

// Listar todas as vagas
router.get('/jobs', (req, res) => {
  try {
    console.log('[v0] Buscando vagas...')
    const jobs = db.prepare('SELECT * FROM jobs ORDER BY created_at DESC').all()
    res.json(jobs)
  } catch (error) {
    console.error('[v0] Erro ao buscar vagas:', error)
    res.status(500).json({ message: 'Erro ao buscar vagas' })
  }
})

// Adicionar nova vaga
router.post('/jobs', (req, res) => {
  try {
    const { title, company, location, type, salary, description, requirements } = req.body

    // Validação básica
    if (!title || !company || !location || !description) {
      return res.status(400).json({ 
        message: 'Título, empresa, localização e descrição são obrigatórios' 
      })
    }

    console.log('[v0] Adicionando vaga:', title)

    // Insere vaga no banco
    const stmt = db.prepare(`
      INSERT INTO jobs (title, company, location, type, salary, description, requirements)
      VALUES (?, ?, ?, ?, ?, ?, ?)
    `)
    
    const result = stmt.run(
      title, 
      company, 
      location, 
      type, 
      salary, 
      description, 
      requirements
    )
    
    res.status(201).json({ 
      message: 'Vaga adicionada com sucesso',
      id: result.lastInsertRowid 
    })
  } catch (error) {
    console.error('[v0] Erro ao adicionar vaga:', error)
    res.status(500).json({ message: 'Erro ao adicionar vaga' })
  }
})

export default router
